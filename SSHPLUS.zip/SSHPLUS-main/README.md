# SSHPLUS

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/CaradeOculos/SSHPLUS/master/Plus && chmod 777 Plus && ./Plus


#Acessa Root

wget https://raw.githubusercontent.com/CaradeOculos/SSHPLUS/master/senharoot.sh && chmod 777 senharoot.sh && ./senharoot.sh
